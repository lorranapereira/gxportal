<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<html lang="en">

<head>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
<title>Gx educação</title>

  <!-- Stylesheets -->
  <link href="/css2/style.css" rel="stylesheet">
  
  <!--Favicon-->
  <link rel="shortcut icon" href="/css/favicon.ico" type="image/x-icon">

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.0/jquery.min.js"></script>
  <script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.4.1.min.js"></script>

  <link href="https://fonts.googleapis.com/css?family=Playfair+Display&display=swap" rel="stylesheet">
  <title>Gx educação</title>
  <link href="https://fonts.googleapis.com/css?family=Abril+Fatface|Rubik:500&display=swap" rel="stylesheet">
<!-- Bootstrap core CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.css">
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick-theme.css">

 <!-- <link href="css/modern-business.css" rel="stylesheet"> -->
  <link rel="stylesheet" href="/css/indexstyle.css" >
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="https://fonts.googleapis.com/css?family=Heebo&display=swap" rel="stylesheet"> 
  <link href="https://fonts.googleapis.com/css?family=Heebo|Jomolhari&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Heebo|Jomolhari|Playfair+Display&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>


<style>
  body {
    position:relative;
    background-attachment: fixed!important;
    background-position: center!important; 
    background-image:url(/css/curso3.jpg); 
    background-size:cover;
  }
</style>
<?php
require_once("layout/navindex.php");  
?>

    <!-- Page Content -->
  <div class="container"  >

    <!-- Page Heading/Breadcrumbs -->
    <br/>
    <br/>
    <br/>



    <!-- Blog Post -->
    <div class="row" >
    <?php foreach ($gxcursos as $row): ?> 
      <br/>
      <div class="row" style="position:relative;margin:10px;font-family: 'Playfair Display', serif;color:white;">
    <br/>
        <h1>
          <strong style="font-size:50px;color:white;font-family: 'Playfair Display', serif;text-shadow: -1px 3px 0px black;"><? echo $row->titulo; ?></strong>
        </h1>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <h4 class="card-text" style="color:white;font-size:30px;"><?echo $row->info; ?></h4>
        <div class="row">
        <div class="col-md-6">
        </div>
        <br/>
        <br/>
        <form action="curso" method="post">
          <input style="display:none;" name="cursoid" value="<? echo $row->id ?>" style="position:relative;" >
          <p style="font-size:22px;color:red">Vagas esgotadas!</p>
          <p style="font-size:22px;" >Em breve abriremos novas turmas</p>
        <!--  <a style="font-size:25px;left:10%;margin:10px;background-color:black;color:white;" href="https://materiais.gxinveste.com.br/jornada-do-investidor" class="btn btn-primary btn-lg">Saiba mais &nbsp<i class="fa fa-plus" style="font-size:30px;color:white"></i></a>
        !-->
      <!-- <button type="submit"  style="font-size:25px;left:10%;margin:10px;background-color:black;color:white;" class="btn btn-primary btn-lg">Saiba mais &nbsp<i class="fa fa-plus" style="font-size:30px;color:white"></i></button>
       !-->
        </form>
        </div>
      </div>
    <?php endforeach ?>


  </div>
  </div>
  </div>
  <script src="https://code.jquery.com/jquery-2.2.0.min.js" type="text/javascript"></script>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/jquery.maskedinput/1.4.1/jquery.maskedinput.min.js"></script>
   


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.11/jquery.mask.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>

    <!-- Slick Slider -->
    <script src="/plugins/slick/slick.min.js"></script>
    <!-- FancyBox -->
    <script src="/plugins/fancybox/jquery.fancybox.min.js"></script>
    <!-- Google Map -->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCC72vZw-6tGqFyRhhg5CkF2fqfILn2Tsw"></script>
    <script src="/plugins/google-map/gmap.js"></script>

    <script src="/plugins/validate.js"></script>
    <script src="/plugins/wow.js"></script>
    <script src="/plugins/jquery-ui.js"></script>
    <script src="/plugins/timePicker.js"></script>
    <script src="/js2/script.js"></script>
  <!-- /.container -->
  <?php
  require_once("layout/footer.php");
  
  ?>
