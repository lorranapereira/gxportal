



<!-- Core plugin JavaScript-->
<script src="/vendor/jquery-easing/jquery.easing.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  <footer class="page-footer font-small blue pt-4" id="footer" style="position:relative;width:100%;top:110%;height:35%;background-color:#1d3b58!important">
  <br/>
  <img class="rounded mx-auto d-block"  src="/css/logo.png" alt="">  <br/>

    <p class="text-center  text-white">Endereço: Rua Barão de Cotegipe - Porto de Gale - sala 8003, Rio Grande - RS <br/></p>
    <p class="text-center text-white">Telefone: (53) 3035-5525 <br/></p>
    <br/>
    <!-- /.container -->
  </footer>
</body>

</html>
